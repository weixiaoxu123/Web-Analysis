﻿Python Version Used:2.7.14

How to run project:
1)Run gui.py file and then you will see an interface.
2)Then input url and it will give you result in form of bengin,malicious or malware