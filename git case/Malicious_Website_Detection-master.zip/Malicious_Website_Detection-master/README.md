# Malicious_Website_Detection
Uses deep learning and machine learning techniques to detect and classify web pages as spam, malware and phishing
